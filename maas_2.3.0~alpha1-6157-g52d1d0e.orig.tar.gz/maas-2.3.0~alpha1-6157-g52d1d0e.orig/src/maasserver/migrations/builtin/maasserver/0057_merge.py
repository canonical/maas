# -*- coding: utf-8 -*-
from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ('maasserver', '0056_add_description_to_fabric_and_space'),
        ('maasserver', '0056_zone_serial_ownership'),
    ]

    operations = [
    ]
