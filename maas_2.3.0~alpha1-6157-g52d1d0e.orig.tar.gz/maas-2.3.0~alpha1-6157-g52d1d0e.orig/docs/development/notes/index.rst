.. -*- mode: rst -*-

*****************
Development notes
*****************

A collection of miscellaneous notes, perhaps first shared as emails with
the development team, that might be useful to developers.


.. toctree::
   :maxdepth: 1

   check-imports
   unhandled-error-in-deferred
   anatomy-of-recommissioning-in-maas-2.0
