==========
MAAS Enums
==========

..
   This only lists the enums that are relevant to outside users,
   e.g. people writing client applications using MAAS's web API.

.. autoclass:: maasserver.enum.NODE_STATUS
   :members:
