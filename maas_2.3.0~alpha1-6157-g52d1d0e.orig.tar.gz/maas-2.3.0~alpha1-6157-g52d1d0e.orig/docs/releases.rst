*************
MAAS Releases
*************

Stable Release
==============

1.9
---

 * Status: Old Stable Release
 * Latest version: 1.9.4
 * Support: Ubuntu Trusty LTS. Only critical issues.

2.2
---

 * Status: Current Stable Release
 * Latest version: 2.2.0
 * Support: Ubuntu Xenial LTS & PPA.

Development release
===================

2.3
---

 * Status: Current development release
 * Localtion: ppa:maas/next
