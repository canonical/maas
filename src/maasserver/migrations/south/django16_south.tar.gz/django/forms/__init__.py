"""
Django validation and HTML form handling.
"""

from __future__ import absolute_import

from django.core.exceptions import ValidationError
from django.forms.fields import *
from django.forms.forms import *
from django.forms.models import *
from django.forms.widgets import *
