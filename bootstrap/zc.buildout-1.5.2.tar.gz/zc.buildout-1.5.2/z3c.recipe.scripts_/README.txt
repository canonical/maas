********************************
Buildout Script Recipe
********************************

.. contents::

The script recipe installs eggs into a buildout eggs directory, exactly
like zc.recipe.egg, and then generates scripts in a buildout bin
directory with egg paths baked into them.

